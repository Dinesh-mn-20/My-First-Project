import java.math.BigInteger;

public class ElgamalNew {
    public static BigInteger sq_mul(BigInteger a, BigInteger x, BigInteger n) {
        BigInteger y = BigInteger.ONE;
        while (x.compareTo(BigInteger.ZERO) > 0) {
            BigInteger[] divAndRemainder = x.divideAndRemainder(BigInteger.valueOf(2));
            BigInteger rem = divAndRemainder[1];

            if (divAndRemainder[0].compareTo(BigInteger.ZERO) > 0) {
                if (rem.equals(BigInteger.ONE)) {
                    y = y.multiply(a).mod(n);
                    a = a.multiply(a).mod(n);
                } else {
                    a = a.multiply(a).mod(n);
                }
            } else {
                y = y.multiply(a).mod(n);
                break;
            }
            x = x.divide(BigInteger.valueOf(2));
        }
        return y;
    }

    public static BigInteger inverse(BigInteger a, BigInteger n) {
        BigInteger m0 = n;
        BigInteger x0 = BigInteger.ZERO;
        BigInteger x1 = BigInteger.ONE;

        if (n.equals(BigInteger.ONE)) {
            return BigInteger.ZERO;
        }

        while (a.compareTo(BigInteger.ONE) > 0) {
            BigInteger[] divAndRemainder = a.divideAndRemainder(n);
            BigInteger q = divAndRemainder[0];
            BigInteger t = n;

            n = divAndRemainder[1];
            a = t;
            t = x0;
            x0 = x1.subtract(q.multiply(x0));
            x1 = t;
        }

        if (x1.compareTo(BigInteger.ZERO) < 0) {
            x1 = x1.add(m0);
        }

        return x1;
    }

    public static void main(String[] args) {
        BigInteger p = new BigInteger("3119");
        BigInteger e1 = new BigInteger("2");
        BigInteger d = new BigInteger("127");
        BigInteger e2 = sq_mul(e1, d, p);
        BigInteger r = new BigInteger("307");
        BigInteger M = new BigInteger("320");
        BigInteger S1 = sq_mul(e1, r, p);
        BigInteger ss = inverse(r, p.subtract(BigInteger.valueOf(1)));
        BigInteger S2 = M.subtract(d.multiply(S1));
        S2=S2.multiply(ss);
        S2=S2.mod(p.subtract(BigInteger.valueOf(1)));
        System.out.println("S1 "+S1);
        System.out.println("S2 "+S2);
        S2=S2.mod(p.subtract(BigInteger.valueOf(1)));
        BigInteger v1 = sq_mul(e1, M, p);
        BigInteger q1 = sq_mul(e2, S1, p); 
        BigInteger q2= sq_mul(S1, S2, p);
        BigInteger v2=q1.multiply(q2);
        
        v2=v2.mod(p);
        System.out.println("V1 "+v1);
        System.out.println("V2 "+v2);
    }
}
