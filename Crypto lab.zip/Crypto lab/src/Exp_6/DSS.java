package Exp_6;

import java.math.BigInteger;

public class DSS {
    public static BigInteger sq_mul(BigInteger a, BigInteger x, BigInteger n) {
        BigInteger y = BigInteger.ONE;
        while (x.compareTo(BigInteger.ZERO) > 0) {
            BigInteger[] divAndRemainder = x.divideAndRemainder(BigInteger.valueOf(2));
            BigInteger rem = divAndRemainder[1];

            if (divAndRemainder[0].compareTo(BigInteger.ZERO) > 0) {
                if (rem.equals(BigInteger.ONE)) {
                    y = y.multiply(a).mod(n);
                    a = a.multiply(a).mod(n);
                } else {
                    a = a.multiply(a).mod(n);
                 }
            } else {
                y = y.multiply(a).mod(n);
                break;
            }
            x = x.divide(BigInteger.valueOf(2));
        }
        return y;
    }

    public static BigInteger inverse(BigInteger a, BigInteger n) {
        BigInteger m0 = n; 
        BigInteger x0 = BigInteger.ZERO;
        BigInteger x1 = BigInteger.ONE;

        if (n.equals(BigInteger.ONE)) {
            return BigInteger.ZERO;
        }

        while (a.compareTo(BigInteger.ONE) > 0) {
            BigInteger[] divAndRemainder = a.divideAndRemainder(n);
            BigInteger q = divAndRemainder[0];
            BigInteger t = n;

            n = divAndRemainder[1];
            a = t;
            t = x0;
            x0 = x1.subtract(q.multiply(x0));
            x1 = t;
        }

        if (x1.compareTo(BigInteger.ZERO) < 0) {
            x1 = x1.add(m0);
        }

        return x1;
    }

    public static void main(String[] args) {
        BigInteger p = BigInteger.valueOf(283);
        BigInteger q = new BigInteger("47");
        
        BigInteger e1 = BigInteger.valueOf(60);   
        BigInteger d = new BigInteger("24");
        BigInteger r = BigInteger.valueOf(15);
        BigInteger M = new BigInteger("41");
        
        BigInteger e2 = sq_mul(e1, d, p);
        
        System.out.println("e2: "+e2);
        
        
        BigInteger S1 = sq_mul(e1, r, p).mod(q);
        BigInteger S2 = M.add(d.multiply(S1));
        BigInteger r_inv = inverse(r,q);
        S2=S2.multiply(r_inv);
        S2=S2.mod(q);
        System.out.println("S1: "+S1);
        System.out.println("S2: "+S2);
        
        
        BigInteger S2_inv = inverse(S2,q);
        
        BigInteger u1=(M.multiply(S2_inv)).mod(q);
        BigInteger u2=(S1.multiply(S2_inv)).mod(q);
        
        BigInteger i=sq_mul(e1 , u1, p);
        BigInteger j=sq_mul(e2 , u2,p);
        i=i.multiply(j);
        i=i.mod(p);

        BigInteger V= i.mod(q);
        
        System.out.println("V: "+V);
        
    }
}
