/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exp_2;

public class WordToMatrix {
    public static void main(String[] args) {
        String word = "ABCD"; // Replace with your four-letter word

        if (word.length() != 4) {
            System.out.println("The input word must be exactly four letters.");
            return;
        }

        int[][] matrix = new int[2][2];

        for (int i = 0; i < 4; i++) {
            int row = i / 2;
            int col = i % 2;
            matrix[row][col] = word.charAt(i)-65;
        }

        // Display the 2x2 matrix
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println(); // Move to the next row
        }
    }
}
