
import java.util.Scanner;

public class Hill
{
    public static int[][] multiplyMatricesMod26(int[][] matrixA, int[][] matrixB) {
        int rowsA = matrixA.length;
        int colsA = matrixA[0].length;
        int colsB = matrixB[0].length;

        if (matrixB.length != colsA) {
            throw new IllegalArgumentException("Number of columns in matrixA must be equal to the number of rows in matrixB.");
        }

        int[][] result = new int[rowsA][colsB];

        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                int sum = 0;
                for (int k = 0; k < colsA; k++) {
                    sum += matrixA[i][k] * matrixB[k][j];
                }
                result[i][j] = sum % 26; // Take the result modulo 26
            }
        }

        return result;
    }

    
    private static int modInverse(int a, int m) {
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        throw new ArithmeticException("Modular inverse does not exist.");
    }
    
    
    public static int[][] inverse(int[][] matrix){
        int n = matrix.length;
        int[][] augmentedMatrix = new int[n][2 * n];

        // Create an augmented matrix [matrix | I] where I is the identity matrix
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                augmentedMatrix[i][j] = matrix[i][j];
                augmentedMatrix[i][j + n] = (i == j) ? 1 : 0;
            }
        }

        // Apply Gaussian elimination to transform the left side into the identity matrix
        for (int i = 0; i < n; i++) {
            int pivotIdx = -1;
            for (int j = i; j < n; j++) {
                if (augmentedMatrix[j][i] != 0) {
                    pivotIdx = j;
                    break;
                }
            }

            if (pivotIdx == -1) {
                throw new ArithmeticException("Matrix is not invertible modulo 26.");
            }

            // Swap rows to make the pivot element non-zero
            int[] temp = augmentedMatrix[i];
            augmentedMatrix[i] = augmentedMatrix[pivotIdx];
            augmentedMatrix[pivotIdx] = temp;

            int pivot = augmentedMatrix[i][i];
            int pivotInverse = modInverse(pivot, 26);

            // Scale the row to make the pivot element 1
            for (int j = 0; j < 2 * n; j++) {
                augmentedMatrix[i][j] = (augmentedMatrix[i][j] * pivotInverse) % 26;
            }

            // Eliminate other rows
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    int factor = augmentedMatrix[j][i];
                    for (int k = 0; k < 2 * n; k++) {
                        augmentedMatrix[j][k] = (augmentedMatrix[j][k] - (factor * augmentedMatrix[i][k])) % 26;
                        if (augmentedMatrix[j][k] < 0) {
                            augmentedMatrix[j][k] += 26;
                        }
                    }
                }
            }
        }

        // Extract the right side of the augmented matrix as the inverse
        int[][] inverseMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                inverseMatrix[i][j] = augmentedMatrix[i][j + n];
            }
        }

        return inverseMatrix;
    }
    public static int[][] wordtoMat(String word){
         int[][] matrix = new int[2][2];
         int[][] result = new int[2][2];

        for (int i = 0; i < 4; i++) {
            int row = i / 2;
            int col = i % 2;
            matrix[row][col] = word.charAt(i)-97;
        }
         for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                result[i][j] = matrix[j][i];
            }
        }
        return result;
    }
	public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            String plain,ciphertxt;
	    System.out.print("Enter the text: ");
            plain=sc.next();
            System.out.print("Enter the ciphertext: ");
            ciphertxt=sc.next();
        int [][] text = wordtoMat(plain);
        int [][] cipher = wordtoMat(ciphertxt);
        int[][] inverse = inverse(text);
                System.out.println("-------KEY --------");
         
        int [][]mulMat = multiplyMatricesMod26(cipher, inverse);
	
        
        String key="";
        key=key+(char)(mulMat[0][0]+97);
        key=key+(char)(mulMat[0][1]+97);
        key=key+(char)(mulMat[1][0]+97);
        key=key+(char)(mulMat[1][1]+97);
        
        
            System.out.println("key: "+key);
	    
	}
}
