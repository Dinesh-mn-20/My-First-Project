/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exp_3;
import java.util.Scanner;
public class temp {
	String Encryption(String s,int shift){
    	String ans="";
    	for(char c:s.toCharArray()){
        	if(Character.isUpperCase(c)){
            	int t1=(c-'A'+shift)%26;
            	char t2=(char)(t1+'A');
            	ans+=t2;
        	}      	
        	else if(Character.isLowerCase(c)){
            	int t1=(c-'a'+shift)%26;
            	char t2=(char)(t1+'a');
            	ans+=t2;
        	}
        	else return("");
            	
    	}
    	return ans;
	}
	String Decryption(String s,int shift){
    	String ans="";
    	for(char c:s.toCharArray()){
        	if(Character.isUpperCase(c)){
            	int t1=(c-'A'-shift)%26;
            	char t2=(char)(t1+'A');
            	ans+=t2;
        	}
        	else if(Character.isLowerCase(c)){
            	int t1=(c-'a'-shift)%26;
            	char t2=(char)(t1+'a');
            	ans+=t2;
        	}
        	else return("");
    	}
    	return ans;
	}
	public static void main(String[] args) {
   	 Scanner sc=new Scanner(System.in);
    	temp obj=new temp();
 
    	System.out.println("Enter text to be encrypted: ");
    	String plaintext=sc.next();
    	System.out.println("Enter shift key: ");
    	int shift=sc.nextInt();
    	String ans=obj.Encryption(plaintext,shift);
 
    	System.out.println("\nEncrypted text: "+ans);
 
    	ans=obj.Decryption(ans,shift);
    	System.out.println("\nDecrypted text: "+ans);
	}
}

