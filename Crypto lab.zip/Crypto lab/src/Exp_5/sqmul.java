/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exp_5;

/**
 *
 * @author dinesh
 */
public class sqmul {
    public static long sq_mul(long a, long x, long n) {
        long y = 1;
        while (x > 0) {
            long rem = x % 2;
            if (x / 2 > 0) {
                if (rem == 1) {
                    y = (y * a) % n;
                    a = a * a % n;
                } else {
                    a = a * a % n;
                }
            } else {
                y = (y * a) % n;
                break;
            }
            x = x / 2;
        }

        return y;
    }
     public static int inverse(int a, int n) {
        int m0 = n;
        int x0 = 0;
        int x1 = 1;
        if (n == 1) {
            return 0;
        }
        while (a > 1) {
            int q = a / n;
            int t = n;

            n = a % n;
            a = t;
            t = x0;
            x0 = x1 - q * x0;
            x1 = t;
        }
        if (x1 < 0) {
            x1 += m0;
        }
        return x1;
    }
    public static void main(String[] args) {
        long a=sq_mul(1702, 2083, 3119);
        long b=sq_mul(2083, 2105, 3119);
        
        System.out.println(571774244%3119);
    }
}
