//package Exp_1;
//import java.util.*;
//     public class Transposition {
//        public static void main(String[] args) {
//            Scanner scan = new Scanner(System.in);
//            System.out.println("1. Encryt 2.Decrypt : ");
//            int option = scan.nextInt();
//            switch (option) {
//                case 1:
//                    System.out.print("Enter String:");
//                    String text = scan.next();
// 
//                    System.out.print("Enter Key:");
//                    String key = scan.next();
//                    System.out.println(encryptCT(key, text).toUpperCase());
//                    break;
//                case 2:
//                    System.out.print("Enter Encrypted String:");
//                    text = scan.next();
//                     System.out.print("Enter Key:");
//                    key = scan.next();
//                     System.out.println(decryptCT(key, text));
//                    break;
//                default:
//                    break;
//            }
//        }
//         public static String encryptCT(String key, String text) {
//            int[] arrange = arrangeKey(key);
//             int lenkey = arrange.length;
//            int lentext = text.length();
//             int row = (int) Math.ceil((double) lentext / lenkey);
//             char[][] grid = new char[row][lenkey];
//            int z = 0;
//            for (int x = 0; x < row; x++) {
//                for (int y = 0; y < lenkey; y++) {
//                    if (lentext == z) {
//                        grid[x][y] = RandomAlpha();
//                        z--;
//                    } else {
//                        grid[x][y] = text.charAt(z);
//                    }
//                     z++;
//                }
//            }
//            String enc = "";
//            for (int x = 0; x < lenkey; x++) {
//                for (int y = 0; y < lenkey; y++) {
//                    if (x == arrange[y]) {
//                        for (int a = 0; a < row; a++) {
//                            enc = enc + grid[a][y];
//                        }
//                    }
//                }
//            }
//            return enc;
//        }
//         public static String decryptCT(String key, String text) {
//            int[] arrange = arrangeKey(key);
//            int lenkey = arrange.length;
//            int lentext = text.length();
//             int row = (int) Math.ceil((double) lentext / lenkey);
//             String regex = "(?<=\\G.{" + row + "})";
//            String[] get = text.split(regex);
//             char[][] grid = new char[row][lenkey];
//             for (int x = 0; x < lenkey; x++) {
//                for (int y = 0; y < lenkey; y++) {
//                    if (arrange[x] == y) {
//                        for (int z = 0; z < row; z++) {
//                            grid[z][y] = get[arrange[y]].charAt(z);
//                        }
//                    }
//                }
//            }
//             String dec = "";
//            for (int x = 0; x < row; x++) {
//                for (int y = 0; y < lenkey; y++) {
//                    dec = dec + grid[x][y];
//                }
//            }
//             return dec;
//        }
//         public static char RandomAlpha() {
//            Random r = new Random();
//            return (char)(r.nextInt(26) + 'a');
//        }
//         public static int[] arrangeKey(String key) {
//            String[] keys = key.split("");
//            Arrays.sort(keys);
//            int[] num = new int[key.length()];
//            for (int x = 0; x < keys.length; x++) {
//                for (int y = 0; y < key.length(); y++) {
//                    if (keys[x].equals(key.charAt(y) + "")) {
//                        num[y] = x;
//                        break;
//                    }
//                }
//            }
//             return num;
//        } 
//    }


package Exp_1;
import java.util.*;

public class Transposition{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(true){
            System.out.println("1. Encrypt\t2. Decrypt\t3. Exit ");
            System.out.print("Enter your choice: ");
            int option = scanner.nextInt();
            switch (option) {
                case 1:
                    System.out.print("Enter the text to encrypt: ");
                    String text = scanner.next();

                    System.out.print("Enter the encryption key: ");
                    String key = scanner.next();

                    String encryptedText = encryptUsingColumnarTransposition(key, text);
                    System.out.println("Encrypted Text: " + encryptedText.toUpperCase());
                    break;

                case 2:
                    System.out.print("Enter the encrypted text: ");
                    text = scanner.next();

                    System.out.print("Enter the decryption key: ");
                    key = scanner.next();

                    String decryptedText = decryptUsingColumnarTransposition(key, text);
                    System.out.println("Decrypted Text: " + decryptedText);
                    break;
             }
            System.out.println("\n");
            if(option==3){
                break;
            }
        }
        
    }

    // Encrypt text using Columnar Transposition
    public static String encryptUsingColumnarTransposition(String key, String text) {
        int[] columnOrder = arrangeKey(key);
        int keyLength = columnOrder.length;
        int textLength = text.length();
        int numRows = (int) Math.ceil((double) textLength / keyLength);

        char[][] grid = new char[numRows][keyLength];
        int charIndex = 0;

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < keyLength; col++) {
                if (charIndex == textLength) {
                    grid[row][col] = RandomAlpha();
                    charIndex--;
                } else {
                    grid[row][col] = text.charAt(charIndex);
                }
                charIndex++;
            }
        }

        StringBuilder encryptedText = new StringBuilder();

        for (int col = 0; col < keyLength; col++) {
            for (int i = 0; i < keyLength; i++) {
                if (col == columnOrder[i]) {
                    for (char[] row : grid) {
                        encryptedText.append(row[i]);
                    }
                }
            }
        }

        return encryptedText.toString();
    }

    // Decrypt text using Columnar Transposition
    public static String decryptUsingColumnarTransposition(String key, String text) {
        int[] columnOrder = arrangeKey(key);
        int keyLength = columnOrder.length;
        int textLength = text.length();
        int numRows = (int) Math.ceil((double) textLength / keyLength);

        String regex = "(?<=\\G.{" + numRows + "})";
        String[] parts = text.split(regex);

        char[][] grid = new char[numRows][keyLength];

        for (int col = 0; col < keyLength; col++) {
            for (int i = 0; i < keyLength; i++) {
                if (columnOrder[col] == i) {
                    for (int row = 0; row < numRows; row++) {
                        grid[row][i] = parts[columnOrder[i]].charAt(row);
                    }
                }
            }
        }

        StringBuilder decryptedText = new StringBuilder();

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < keyLength; col++) {
                decryptedText.append(grid[row][col]);
            }
        }

        return decryptedText.toString();
    }

    // Generate a random lowercase letter
    public static char RandomAlpha() {
        Random random = new Random();
        return (char)(random.nextInt(26) + 'a');
    }

    // Arrange the key in ascending order and return the column order
    public static int[] arrangeKey(String key) {
        String[] keys = key.split("");
        Arrays.sort(keys);
        int[] columnOrder = new int[key.length()];
        
        for (int i = 0; i < keys.length; i++) {
            for (int j = 0; j < key.length(); j++) {
                if (keys[i].equals(key.charAt(j) + "")) {
                    columnOrder[j] = i;
                    break;
                }
            }
        }
        
        return columnOrder;
    }
}
