/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exp_1;






public class Hill_working {
    public static int[][] getkeymat(String s){
        int[][] key=new int[2][2];
        int k=0;
        
        for(int i=0;i<2;i++ ){
            for(int j=0;j<2;j++){
                int ascii=s.charAt(k)-97;
                key[i][j]=ascii;
                k++;
            }
        }
        return key;
    }
    public static int inverse(int r2){
        if(GCD(26,r2)==1){
            int r1=26;
            int t1=0;
            int t2=1;                    ;
            int q,r,t;
            while(r2!=0){
                q=r1/r2;
                r=r1%r2;
                t=t1-(q*t2);
                r1=r2;
                r2=r;
                t1=t2;
                t2=t;
            }
            if(t1<0){
                return t1+26;
            }
            else{
                return t1;
            }
        }
        else{
            return -1;
        }
    }
    public static int GCD(int a,int b){
        if(a==0 || b==0){
            return 0;
        }
        if(a==b){
            return a;
        }
        if(a>b){
            return GCD(a-b, b);
        }
        else{
            return GCD(a, b-a);
        }
    }
    public static int[] getplainmat(String s){
        int plain[] = new int[2];
        
        for(int i=0;i<2;i++){
            plain[i]=(int)s.charAt(i)-97;
        }
        return plain;
    }
    public static String encrypt(int[] plain,int[][] key){
        
        int a =( (plain[0]*key[0][0]) + (plain[1]*key[0][1]) )%26 ;
        int b=( (plain[0]*key[1][0]) + (plain[1]*key[1][1]) )%26 ;
        
        String res="";
        res+=(char)(a+97);
        res+=(char)(b+97);
        
        return res;
    }
    public static int[][] getinvMat(int[][] mat){
        int det=((mat[0][0]*mat[1][1])-(mat[1][0]*mat[0][1]) )%26 ;
        int[][] inv=new int[2][2];
        int det_inv=inverse(det);
        
        inv[0][0] =( mat[1][1] * det_inv ) %26;
        inv[1][1] =( mat[0][0] * det_inv ) %26;
        
        inv[0][1] =((26- mat[0][1] )* det_inv ) %26;
        inv[1][0] =((26- mat[1][0] )* det_inv ) %26;    
        return inv;
    }
    public static void main(String[] args) {
        int[][] keyMat;
        String plaintext="dinesh";
        String key="hell";
        
        keyMat=getkeymat(key);
        
//        for(int i=0;i<2;i++){
//            for(int j=0;j<2;j++){
//                System.out.println(keyMat[i][j]);
//            }
//        }
        String p="";
        String ciphertext="";
        for(int i=0;i<plaintext.length();i++){
            p=p+plaintext.charAt(i);
            if(p.length()==2){
                  int[] plain ;
                  plain=getplainmat(p);
//                  for(int j=0;j<2;j++){
//                      System.out.print(plain[j]);
//                  }
//                  System.out.println("\n");
                    ciphertext+=encrypt(plain, keyMat);
                  p="";
            }
        }
        System.out.println(ciphertext);
        String c="";
        String ans="";
        int[][] invMat=getinvMat(keyMat);
        for(int i=0;i<2;i++){
            for(int j=0;j<2;j++){
                System.out.println(invMat[i][j]);
            }
        }
        for(int i=0;i<plaintext.length();i++){
            c=c+ciphertext.charAt(i);
            if(c.length()==2){
                  int[] plain ;
                  plain=getplainmat(c);
                  ans+=encrypt(plain, invMat);
                  
                  c="";
            }
        }
        System.out.println(ans);
    }
    
}
